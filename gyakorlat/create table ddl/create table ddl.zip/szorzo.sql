--------------------------------------------------------
--  File created - p�ntek-m�jus-12-2017   
--------------------------------------------------------
-- Unable to render TABLE DDL for object SZORZO with DBMS_METADATA attempting internal generator.
CREATE TABLE SZORZO 
(
  SZORZO VARCHAR2(1 BYTE) 
);


REM INSERTING into SZORZO
SET DEFINE OFF;
Insert into SZORZO (SZORZO) values ('X');
Insert into SZORZO (SZORZO) values ('X');
Insert into SZORZO (SZORZO) values ('X');
commit;
