--------------------------------------------------------
--  File created - p�ntek-m�jus-12-2017   
--------------------------------------------------------
-- Unable to render TABLE DDL for object ALKALMAZOTT with DBMS_METADATA attempting internal generator.
CREATE TABLE ALKALMAZOTT 
(
  AID NUMBER(3, 0) 
, NEV VARCHAR2(40 BYTE) NOT NULL 
, SZULEV NUMBER(4, 0) NOT NULL 
) ;

REM INSERTING into ALKALMAZOTT
SET DEFINE OFF;
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('1','Bana �rp�dn�','1967');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('2','Szab� Lajosn�','1958');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('3','Pord�n Gy�ngyi','1954');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('4','Szerdahelyi Ad�l','1960');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('5','Rezes Andr�sn�','1973');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('6','Babos Krisztina','1967');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('7','M�ri�s K�roly','1951');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('8','Mik� Annam�ria','1972');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('9','Solymosi Andr�sn�','1967');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('10','V�rhegyi Krisztina','1964');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('11','Kov�csn� Brigitta','1978');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('12','Papp K�zm�r','1972');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('13','Teleki Annam�ria','1968');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('14','Kov�cs Ad�l','1986');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('15','Papp Korn�lia','1966');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('16','Vojevogyina Al�z','1952');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('17','T�th Ferenc','1954');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('18','Szo� �gota','1979');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('19','Karajos Alexa','1965');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('20','V�rkonyi Mikl�sn�','1977');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('21','Fodor Em�lia','1978');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('22','Papcs�k Adonisz','1974');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('23','Mester Tiborn�','1953');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('24','Vid�k �ron','1991');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('25','Szendi Tam�s','1947');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('26','Mizi Krisztina','1970');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('27','Szerdahelyi Kriszta','1986');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('28','Krausz Attil�n�','1991');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('29','Lipcsei Rita','1987');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('30','Sz�nt� K�roly','1962');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('31','Bukovics Erika','1981');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('32','�rdi L�szl�','1989');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('33','Kiss Gergely','1976');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('34','Egressy Istv�n','1964');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('35','Pettendi Csaba','1979');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('36','Fekete Liza','1968');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('37','Jo� M�ria','1956');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('38','Ko�s Alajos','1990');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('39','Kerekes Zsombor','1971');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('40','Komondi Aletta','1971');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('41','Mizi Marietta','1948');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('42','�lmosdi Tibor','1989');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('43','Kerezsi Anita','1957');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('44','Kassai J�nosn�','1960');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('45','Pongr�cz Zolt�nn�','1954');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('46','Keresztes Tibor','1954');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('47','Kiss Hedvig','1949');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('48','R�thn� �va','1954');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('49','P�szti Annam�ria','1978');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('50','Moln�rn� J�lia','1947');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('51','Er�s Andrea','1978');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('52','Asztalos �d�m','1948');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('53','Eszes Krisztina','1961');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('54','Kov�cs Marianna','1960');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('55','Kov�cs G�z�n�','1955');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('56','Szab� �kosn�','1979');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('57','Nagy-Sz�nt� Anna','1991');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('58','Kerek G�bor','1961');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('59','Kocsis Kriszti�n','1974');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('60','Veres Adri�n','1977');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('61','Kiss Laura','1978');
Insert into ALKALMAZOTT (AID,NEV,SZULEV) values ('62','Good Henrik','1949');
commit;
